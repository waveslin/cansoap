-- MySqlBackup.NET 2.0.9.2
-- Dump Time: 2021-02-19 20:26:48
-- --------------------------------------
-- Server version 5.7.26-log MySQL Community Server (GPL)

-- 
-- Create schema cansoap
-- 

CREATE DATABASE IF NOT EXISTS `cansoap` /*!40100 DEFAULT CHARACTER SET utf8 */;
Use `cansoap`;



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of migrations
-- 

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 
-- Dumping data for table migrations
-- 

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations`(`id`,`migration`,`batch`) VALUES
(1,'2020_08_12_105306_create_products_table',1),
(4,'2020_08_21_072835_create_orders_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- 
-- Definition of orders
-- 

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `oid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `taxes` decimal(10,2) NOT NULL,
  `shipping_fee` decimal(10,2) NOT NULL,
  `shipping_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`oid`),
  UNIQUE KEY `orders_sid_unique` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 
-- Dumping data for table orders
-- 

/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders`(`oid`,`firstname`,`lastname`,`address`,`city`,`province`,`postal`,`phone`,`email`,`total`,`taxes`,`shipping_fee`,`shipping_company`,`sid`,`description`,`created_at`,`updated_at`) VALUES
('10257213-2b42-4358-865e-8cb933143a25','Henry','Chang','555 Java street','Toronto','ON','M4B 1B3',4167772121,'HenryChang@gmail.com',200.10,26.10,0.00,NULL,NULL,'Fapik Bar Soap:=1|Woll Bar Soap:=9|Moni Bar Soap:=3|Ulta Bar Soap:=1|Newo Bar Soap:=1|Neti Bar Soap:=3|Diga Bar Soap:=2|','2020-11-15 11:55:42','2020-11-15 11:55:42'),
('28e723f6-25c0-459f-a1d5-d500f2056064','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',36.08,3.00,13.08,NULL,NULL,'Jert Bar Soap:=2|','2021-02-19 06:25:06','2021-02-19 06:25:06'),
('375f7378-162c-4cbc-9e73-b24f205d53df','Johnny','Fang','4410 Saint kool Street','Montreal','QC','L4T7G1',4138739911,'johnnyfang@hotmail.com',68.28,7.20,13.08,NULL,NULL,'Mile Bar Soap:=2|Moni Bar Soap:=2|Woll Bar Soap:=2|','2020-10-31 16:11:41','2020-10-31 16:11:41'),
('37c2d62b-8c64-444c-8d01-8ec1c2687ffc','Christin','Lin','3333 St Mathieu St','Montreal','QC','H3H2J8',4138739911,'ChristinLin@outlook.com',54.48,5.40,13.08,NULL,NULL,'Lodie Bar Soap:=3|','2020-12-17 07:00:18','2020-12-17 07:00:18'),
('39845973-a560-4461-bc87-468af129c7aa','Julia','Cake','881 Heralon Street','Toronto','ON','K1E4S7',5245558899,'JuliaCake@gmail.com',100.63,13.13,0.00,NULL,NULL,'Fapik Bar Soap:=5|Golda Bar Soap:=4|Cler Bar Soap:=1|','2020-11-01 10:49:43','2020-11-01 10:49:43'),
('3b57a7a4-431c-40c9-a653-80336884fdb1','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',40.68,3.60,13.08,NULL,NULL,'Whai Bar Soap:=3|','2021-02-19 05:46:36','2021-02-19 05:46:36'),
('3bfdb871-3b81-448e-a444-1c118f995a86','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',40.68,3.60,13.08,NULL,NULL,'Whai Bar Soap:=3|','2021-02-19 06:32:32','2021-02-19 06:32:32'),
('487d8c3f-3e7a-46b5-b366-5d53b500010a','Christin','Lin','662 Saint Kenne Street','Montreal','QC','H6H8G8',5146662323,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Mile Bar Soap:=1|','2020-11-16 13:30:44','2020-11-16 13:30:44'),
('4dffb2af-f18e-415f-8b83-02b499bd01d4','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Mile Bar Soap:=1|','2021-02-19 06:26:06','2021-02-19 06:26:06'),
('4fe96be5-8adb-4824-8ba5-9d1dd1a1a8d1','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',5146661212,'christinLin@gmail.com',68.28,7.20,13.08,NULL,NULL,'Fapik Bar Soap:=3|Moni Bar Soap:=3|','2021-02-19 04:55:42','2021-02-19 04:55:42'),
('562c0081-0b25-4cc7-ba17-1eca7963ec6f','Christin','Lin','3333 St Mathieu St','Montreal','QC','H3H2J8',4138739911,'ChristinLin@outlook.com',95.88,10.80,13.08,NULL,NULL,'Wica Bar Soap:=6|','2020-12-17 07:47:13','2020-12-17 07:47:13'),
('827f484a-18dc-427a-a2b1-9bc72d5a8ac1','Peter','Zhou','4160 Goodstreem Street','Toronto','ON','D8K9U2',4160092241,'PeterZHOU@gmail.com',22.28,1.20,13.08,NULL,NULL,'Whai Bar Soap:=1|','2020-11-16 13:32:01','2020-11-16 13:32:01'),
('82de32b8-9ed9-41be-94da-a6bd8a6d6428','Christin','Lin','662 Saint Kenne Street','Montreal','QC','H6H8G8',5146662323,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Fapik Bar Soap:=1|','2020-11-16 13:58:22','2020-11-16 13:58:22'),
('896860ee-66a8-41e6-a10b-8266b5a93548','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Fapik Bar Soap:=1|','2021-02-19 06:30:19','2021-02-19 06:30:19'),
('955b267c-7928-486f-903f-4cae222289eb','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Mile Bar Soap:=1|','2021-02-19 06:27:19','2021-02-19 06:27:19'),
('a41121cc-fe93-4742-b3cf-ccc462fde508','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Whai Bar Soap:=1|','2021-02-19 23:37:44','2021-02-19 23:37:44'),
('ad27d806-8485-4ccd-bcc7-8d5b8f6d9095','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',43.56,3.98,13.08,NULL,NULL,'Hotta Bar Soap:=1|Moni Bar Soap:=1|Gami Bar Soap:=1|','2021-02-20 03:23:51','2021-02-20 03:23:51'),
('cec01ff8-4c4f-4ca4-b71c-01a075da7383','Christin','Lin','662 Saint Kenne Street','Montreal','QC','H6H8G8',5146662323,'christinLin@gmail.com',47.58,4.50,13.08,NULL,NULL,'Jert Bar Soap:=3|','2020-11-16 14:09:48','2020-11-16 14:09:48'),
('cee9a6c9-b5d4-46bc-86d8-229e1309f9dc','Winne','Zhang','6620 Saint Fenne Street','Montreal','QC','H5H17Y',514668919,'ZhangWinne@yahoo.com',82.08,9.00,13.08,NULL,NULL,'Whai Bar Soap:=2|Wica Bar Soap:=2|Kiter Bar Soap:=2|','2020-11-15 11:47:17','2020-11-15 11:47:17'),
('d14348c5-e38d-4478-90bd-3859d16f9711','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',106.95,13.95,0.00,NULL,NULL,'Origa Bar Soap:=6|','2021-02-19 05:54:02','2021-02-19 05:54:02'),
('d3039261-69e0-47e1-8a5d-d402c9a62bf4','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',22.28,1.20,13.08,NULL,NULL,'Woll Bar Soap:=1|','2021-02-20 03:24:25','2021-02-20 03:24:25'),
('ddf93f79-0cb7-4f17-85ab-e0d5e3661e95','Christin','Lin','666 Rue Saint Mantis','Montreal','QC','H3H 2P5',445146661212,'christinLin@gmail.com',40.68,3.60,13.08,NULL,NULL,'Diga Bar Soap:=2|','2021-02-19 06:41:27','2021-02-19 06:41:27'),
('e131251b-a121-4256-b681-2d201e3a8ed7','Winne','Zhang','6620 Saint Fenne Street','Montreal','QC','H5H17Y',514668919,'ZhangWinne@yahoo.com',40.68,3.60,13.08,NULL,NULL,'Diga Bar Soap:=2|','2020-11-15 11:13:11','2020-11-15 11:13:11'),
('e5d67729-ad4e-4165-b767-c430aef67f24','Christin','Lin','662 Saint Kenne Street','Montreal','QC','H6H8G8',5146662323,'christinLin@gmail.com',75.18,8.10,13.08,NULL,NULL,'Mile Bar Soap:=4|Diga Bar Soap:=1|Jert Bar Soap:=1|','2020-10-31 15:48:49','2020-10-31 15:48:49'),
('ea560dac-a5e0-4c48-9417-6701a53b99b0','Winne','Zhang','6620 Saint Fenne Street','Montreal','QC','H5H17Y',514668919,'ZhangWinne@yahoo.com',40.68,3.60,13.08,NULL,NULL,'Diga Bar Soap:=2|','2020-11-15 11:05:57','2020-11-15 11:05:57'),
('f9f800e3-6e25-46e7-8655-9359a1d1a1cb','Peter','Zhou','4160 Goodstreem Street','Toronto','ON','D8K9U2',4160092241,'PeterZHOU@gmail.com',31.48,2.40,13.08,NULL,NULL,'Mile Bar Soap:=2|','2020-11-16 13:06:27','2020-11-16 13:06:27');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- 
-- Definition of products
-- 

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ingredients` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL,
  `price` decimal(4,2) NOT NULL,
  `mime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 
-- Dumping data for table products
-- 

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products`(`id`,`name`,`description`,`ingredients`,`weight`,`price`,`mime`,`image`,`created_at`,`updated_at`) VALUES
('bs1597405536','Golda Bar Soap','This soap bar is created from the left over bits of soap that we have left once we''ve trimmed our bars. Like a Phoenix, this bar soap is created from the \"ashes\" of it''s past.','Canola Oil, Aqua, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Fragrance Oil',130,8.00,'image/png','Golda_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406654','Whai Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Enjoy this spicy-sweetness all year round! We won’t wait just for autumn to enjoy this soap bar!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Cucurbita Pepo (Pumpkin) Puree, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Fragrance Oil',130,8.00,'image/png','Whai_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406668','Fapik Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Ground and soothe the soul while soaping up with this mellow mix','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Pogostemon Cablin (Patchouli) Oil, Calendula Officinalis Flower',130,8.00,'image/png','Fapik_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406676','Mile Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Smell fresh, smoky and earthy all in one as you soap up and clean up!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Fragrance Oil, Titanium Dioxide, Mica, Chromium Oxide Green',130,8.00,'image/png','Mile_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406686','Jert Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Make your shower experience even better with a citrus scent wafting through your bathroom!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Citrus Grandis (Grapefruit) Peel Oil, Citrus Sinensis (Orange) Peel Oil, Cymbopogon Schoenanthus (Lemongrass) Oil',130,10.00,'image/png','Jert_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406698','Pukin Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Clear your mind, get ready for the day with this uplifting bar soap, sure to wake up your mind in the early mornings.','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Rosmarinus Officinalis (Rosemary) Oil, Mentha Piperita (Peppermint) Oil, Montmorillonite (French Green Clay)',130,8.00,'image/png','Pukin_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406709','Hotta Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Enjoy this sweet, vanilla goodness while soaping up and getting squeaky clean!','Canola Oil, Aqua, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Fragrance Oil',130,8.00,'image/png','Hotta_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406721','Woll Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks  to make. Made fragrance free.','Canola Seed Oil, Hydrogenated Soybean Oil, Butyrospermum Parkii (Shea Butter) Fruit, Cannabis Sativa (Hemp) Seed Oil, Vitis Vinifera (Grape) Seed Oil, Cera Alba (Beeswax), Limnanthes Alba (Meadowfoam) Seed Oil, Simmondsia Chinensis (Jojoba) Seed Oil, Ricinus Communis (Castor) Seed Oil, Tocopherol (Vitamin E)',130,8.00,'image/png','Woll_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406731','Niate Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Our normal soap recipe cut in half and finished off with coconut milk. Talk about hydrating and a nourishing! Enriched with powerful antioxidants including Vitamin C and E, and essential micro nutrients like selenium, iron, copper and zinc which nourish, repair and heal the skin.','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Cocos Nucifera (Coconut) Milk, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil',130,10.00,'image/png','Niate_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406739','Moni Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make.  Lavender is known to be relaxing and calming.','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Lavandula Angustifolia (Lavender) Oil, CI 77007 (Ultramarine Violet Oxide)',130,8.00,'image/png','Moni_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406748','Wica Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make.  Benefiting from the powerful anti-oxidant and omega-fatty acid profile of sea buckthorn, it will be the perfect thing to hydrate and nourish the skin and to aid those suffering from eczema, acne or psoriasis, our sea buckthorn soap lightly scented with lavender essential oil too!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Lavandula Angustifolia (Lavender) Oil, Hippophae Rhamnoides (Sea Buckthorn) Fruit Oil',130,12.00,'image/png','Wica_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406755','Neti Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Lift your spirits and ground your soul with the lemongrass, patchouli and bergamot!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Pogostemon Cablin (Patchouli) Oil, Cymbopogon Schoenanthus (Lemongrass) Oil, Montmorillonite (Yellow Clay), Titanium Dioxide',130,8.50,'image/png','Neti_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406762','Origa Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Wash up and smell like the perfect kind of morning, waking up while camping - smoky, piney and fresh!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Montmorillonite (Yellow) Clay, Citrus Aurantium Dulcis (Orange) Peel Oil, Pinus Sylvestris (Pine) Leaf Oil, Cedrus Deodora (Cedarwood) Oil, Illite (Red) Clay, Pogostemon Cablin (Patchouli) Oil, Titanium Dioxide, Eugenia Caryophyllus (Clove) Flower Oil',130,15.50,'image/png','Origa_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406768','Lodie Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make.  Indulge in the sweet/tart scent and enjoy the extra benefit of the cranberry seeds as an exfoliation!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Fragrance Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Vaccinium Macrocarpon (Cranberry) Seeds',130,12.00,'image/png','Lodie_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406778','Seveb Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Take the woodsy-spicy scent of Cedar and Saffron in the shower with you, steam up your bathroom and enjoy this scent as it hits the steam.','Canola Oil, Aqua, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Fragrance Oil',130,9.00,'image/png','Seveb_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406785','Cokie Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Let this amazing bar help treat sensitive skin, or just enjoy it for it’s amazing scent! You’ll also be able to enjoy a light exfoliation with the oatmeal bits that are in this bar.','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Avena Sativa (Oat) Kernel Meal, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Fragrance Oil',130,10.50,'image/png','Cokie_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406791','Pani Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Scented with Tea Tree and Eucalyptus Essential Oils, this bar soap is clarifying and will help deter bugs and keep your skin feeling fresh.','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Olea Europaea (Olive) Oil, Eucalyptus Globulus Leaf Oil, Melaleuca Alternifolia (Tea Tree) Leaf Oil, Ground Eucalyptus Globulus Leaf, CI 77891 (Titanium Dioxide)',130,14.00,'image/png','Pani_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406800','Gami Bar Soap','Made with tropical oils and butters, botanicals and emulsifying clays, our cold processed soap takes 6-8 weeks to make. Lather up this awesome floral tea, ginger mix!','Canola Oil, Aqua, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Sodium Lactate, Fragrance Oil, Olea Europaea (Olive) Oil',130,10.50,'image/png','Gami_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406807','Cler Bar Soap','A cold processed bar of soap made with three different types of clay designed for a deep but gentle cleansing. The Clear Complexion Bar is designed for oily and problematic skin. Containing an assortment of natural clays to cleanse, absorb oil, oxygenate and replenish the skin. ','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Multani Mitti Clay, Sodium Lactate, Olea Europaea (Olive) Oil, Rhassoul Clay, Australian Black Clay, Citrus Grandis (Grapefruit) Peel Oil, Citrus Sinensis (Orange) Peel Oil, Lavandula Angustifolia (Lavender) Oil, Cedrus Deodora (Cedarwood) Bark Oil, Cymbopogon Schoenantus (Lemongrass) Oil',130,15.50,'image/png','Cler_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406813','Diga Bar Soap','With added Castor oil to moisturize your hair and scalp, and hops extract to help reduce dry flaky skin and remove dandruff, this amazing shampoo bar will give you all the luscious lather you want but rinse clean away leaving your hair free of residue. Safe for the waterways and gentle enough to use everyday! Refresh the hair with a citrus twist.','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Lupulus (Hops) Extract, Sodium Lactate, Olea Europaea (Olive) Oil, Citrus Grandis (Grapefruit) Peel Oil, Citrus Sinensis (Orange) Peel Oil, Cymbopogon Schoenanthus (Lemongrass) Oil',130,12.00,'image/png','Diga_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406825','Ulta Bar Soap','With added Castor oil to moisturize your hair and scalp, and hops extract to help reduce dry flaky skin and remove dandruff, this amazing shampoo bar will give you all the luscious lather you want but rinse clean away leaving your hair free of residue. Safe for the waterways and gentle enough to use everyday!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Lupulus (Hops) Extract, Sodium Lactate, Olea Europaea (Olive) Oil',130,10.50,'image/png','Ulta_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406835','Kiter Bar Soap','With added Castor oil to moisturize your hair and scalp, and hops extract to help reduce dry flaky skin and remove dandruff, this amazing shampoo bar will give you all the luscious lather you want but rinse clean away leaving your hair free of residue. Safe for the waterways and gentle enough to use everyday! Invigorate and tingle the scalp with the refreshing rosemary mint!','Canola Oil, Water, Cocos Nucifera (Coconut) Oil, Sodium Hydroxide, Canola Shortening (High Oleic Canola Oil, Low Linolenic Canola Oil, Corn Oil, Dimethylpolysiloxane), Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Lupulus (Hops) Extract, Sodium Lactate, Olea Europaea (Olive) Oil, Rosmarinus Officinalis (Rosemary) Leaf Extract, Mentha Piperita (Peppermint) Oil',130,10.00,'image/png','Kiter_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08'),
('bs1597406842','Newo Bar Soap','Our deepest clean yet! This facial cleanser with activated charcoal just needs warm water to activate and you''re good to go. Perfect for problematic and oily skin, it''s anti-fungal, antibacterial, anti-viral, and anti-microbial. It can be used head to toe for an intense deep clean to slough away the dead skin cells without dehydrating the skin! Follow up with your favourite Soapstones facial care products! ','Vegetable Oil, Cocos Nucifera (Coconut) Oil, Hydrogenated Palm Kernel Oil, Butyrospermum Parkii (Shea Butter) Fruit, Theobroma Cacao (Cocoa) Seed Butter, Ricinus Communis (Castor) Seed Oil, Olea Europaea (Olive) Oil, Sodium Hydroxide, Sodium Lactate, Essential Oils',130,10.00,'image/png','Newo_Bar_Soap.jpg','2020-08-14 08:03:08','2020-08-14 08:03:08');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2021-02-19 20:26:48
-- Total time: 0:0:0:0:296 (d:h:m:s:ms)
